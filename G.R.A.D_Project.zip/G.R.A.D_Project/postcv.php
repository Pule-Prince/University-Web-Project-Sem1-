<?php
 include_once("event/notloggedIn.php");
include_once("event/conn.php");
?>

<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>G.R.A.D | Upload</title>

    <link
      href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css"
      rel="stylesheet"
    />
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>

    <link rel="stylesheet" href="css/colors.css" />
    <link rel="stylesheet" href="css/navbar.css" />
    <link rel="stylesheet" href="css/form.css" />
    <link rel="stylesheet" href="css/footer.css" />

    <link rel="preconnect" href="https://fonts.googleapis.com" />
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
    <link
      href="https://fonts.googleapis.com/css2?family=Poppins:wght@100;200;300;400;600;700&display=swap"
      rel="stylesheet"
    />
    <script
      src="https://kit.fontawesome.com/da7a0ef97e.js"
      crossorigin="anonymous"
    ></script>
  </head>
  <body>

  <!-- validate form -->
  <?php
  $mess="";
  $error=true;
  $skills="";
  $pa="";
  $nam="";
  $success="";
  if (isset($_POST["submit"])){
    if(!isset($_POST['skills'])){
      $mess = "fill the form";
    }
    else{


     $skills=trim($_POST['skills']);

    if(strlen(trim($skills))<3)  $mess = "Skills is too short must be > 2";
     else{
      $error=false;
     }

     
    }
  }
?>
<!-- end form validation -->

<?php
$uploadOk = 1;

$target_file="";
if (isset($_POST["submit"])){
    

$target_dir = "uploads/";
$target_file = $target_dir .uniqid().$skills. basename($_FILES["profile"]["name"]);

$extension = strtolower(pathinfo($target_file,PATHINFO_EXTENSION));
// Check if pdf file is a actual pdf file.

if(!in_array($extension, ['pdf', 'docx'])) {
  $mess = "File must be PDF OR DOCX";
  $uploadOk=0;
}
elseif($_FILES["profile"]["size"]==0){
  $mess= "File is required.";
   $uploadOk=0;
}else{  
    $check = filesize($_FILES["profile"]["tmp_name"]);
    if($check !== false) {
      //echo "File is a pdf - " . $check["mime"] . ".";
      $uploadOk = 1;
    } else {
      $mess= "File is not a PDF .";
      $uploadOk = 0;
    }

}

}
?>


<!-- check user if exist in the database -->
 <?php
    //if the message length==0
    // then we don't have form errors
    if($error==false && $uploadOk==1){
      $id=$_SESSION["id"];
      //limit the users by 1
      $sql = "INSERT INTO `documents`( `user_id`, `path`, `skills`) VALUES ('$id','$target_file','$skills')";
      if (mysqli_query($conn, $sql)) {
        move_uploaded_file($_FILES['profile']['tmp_name'],$target_file);
        header("Location: dashboard.php");
      } else {
        echo "Error: " . $sql . "<br>" . mysqli_error($conn);
      }
    }
?>
<!-- end checking user -->

    <form class="form"  enctype="multipart/form-data" action="postcv.php" role = "form" method = "post">
    <div class="text-danger text-center">
           <?php echo $mess ?>
      </div>

      <div class="text-success text-center">
           <?php echo  $success ?>
         </div>
      <h3 class="logo">
        <i class="fa fa-graduation-cap" aria-hidden="true"></i>G.R.A.D
      </h3>
      <h2 class="text-center text-white"><b>Post Your CV</b></h2>
      <label>Your CV</label>
      <input name="profile" type="file" accept=".pdf" />
      <label>Skills</label>
      <input name="skills" type="text"  value="<?php echo $skills ?>" />
      <button  type="submit" name="submit"  class="btn btn-block">Post CV</button>
      <a href="index.php">back</a>
  </form>
  
  </body>
</html>
