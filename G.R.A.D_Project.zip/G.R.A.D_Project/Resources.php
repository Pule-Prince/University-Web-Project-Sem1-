<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>G.R.A.D | Resources</title>

    <link
      href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css"
      rel="stylesheet"
    />
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>

    <link rel="stylesheet" href="css/colors.css" />
    
    <link rel="stylesheet" href="css/cvslist.css" />
    <link rel="stylesheet" href="css/footer.css" />
    <link rel="stylesheet" href="css/navbar.css" />
    <link rel="stylesheet" href="resource.css" />

    <link rel="preconnect" href="https://fonts.googleapis.com" />
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
    <link
      href="https://fonts.googleapis.com/css2?family=Poppins:wght@100;200;300;400;600;700&display=swap"
      rel="stylesheet"
    />
    <script
      src="https://kit.fontawesome.com/da7a0ef97e.js"
      crossorigin="anonymous"
    ></script>
  </head>
  <body>
  <nav> 
      <div class="logo">
        <i class="fa fa-graduation-cap" aria-hidden="true"></i>G.R.A.D
      </div>
      <div class="navLinks">
        <a href="register.php"> <i class="fa fa-user" aria-hidden="true"></i> Sign Up</a>
        <div class="text-white">|</div>
        <a href="login.php"> <i class="fa fa-lock" aria-hidden="true"></i>  Login</a>
      </div>
    </nav>

    <div class="section">
                    <div class="content">
                        
                        <div class="CVandInterview">
                            <p id="head">Create your master class C.V and Polish your interview skills</p>
                        </div>

                        <div class="cvContent">
                            <p id="firstContent">Creating your curriculum vitae is your first step to land a job but you also need to pass an <br>
                            interview for further assessment. In short, you need both CV writing and interview skills to be <br>
                            an outstanding candidate a company would want to hire.
                            </p>
                        </div>

                        <div class="secondContent">
                            <p id="secContent">G.R.A.D has designed resources for individuals who have no experience in CV writing and is yet <br> 
                            to experience their first interview. You will be provided with helpful CV sample guides, writing videos, <br>
                            and interview tips.
                            </p>
                        </div>

                        <div class="pdfandVid">
                            <div class="iconColumn">
                                <i class="fa-solid fa-clapperboard-play fa-8x"></i>
                            </div>
                            <div class="iconColumn">
                                <i class="fa-solid fa-file fa-8x"></i>
                            </div>
                        </div>

                        <div class="pdfs">
                            <div class="template">
                                <embed src="cv-template1.pdf" type="application/pdf">
                            </div>
    
                            <div class="template">
                                <embed src="cv-template2.pdf" type="application/pdf">
                            </div>
    
                            <div class="template">
                                <embed src="cv-template5.pdf" type="application/pdf">
                            </div>
                        </div>
                        <div class="wrapper">
                            <div class="vidwrapper">
                                <iframe width="560" height="315" src="https://www.youtube.com/embed/12Prc9ZA81w" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
                            </div>
                        </div>

                        <div class="warpper2">
                            <div class="videowrapper">
                                <iframe width="560" height="315" src="https://www.youtube.com/embed/HG68Ymazo18" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
                            </div>
                        </div>

                    </div>
                </div>


                <div class="class">
                <a class="twitter-timeline" data-width="400" data-theme="dark" href="https://twitter.com/GRAD46187534?ref_src=twsrc%5Etfw">Tweets by GRAD46187534</a> <script async src="https://platform.twitter.com/widgets.js" charset="utf-8"></script>
                </div>

            <footer class="footer">
                <div class="container">
                    <div class="footerRows">
                        <div class="column">
                            <div class="logo"><i class="fa fa-graduation-cap" aria-hidden="true"></i>G.R.A.D</div>
                            <span id="summary">       
                                G.R.A.D is a startup website made
                                by second year students at the 
                                University of Johannesburg. We are
                                aware of the problem we have been
                                facing regarding unemployment and
                                job searching in general, and we want
                                fill that void.
                            </span>
                        </div>
                        <div class="column">
                            <h4>Quick Links</h4>
                            <ul>
                                <li><a href="dashboard.php">Home</a></li>
                            </ul>
                        </div>
                        <div class="column">
                            <h4>Extra Links</h4>
                            <ul>
                                <li><a href="register.php">Sign Up</a></li>
                                <li><a href="login.php">Login</a></li>
                            </ul>
                        </div>
                        <div class="column">
                            <h4>follow us</h4>
                            <div class="links">
                                <a href="https://www.facebook.com/profile.php?id=100081833985036"><i class="fab fa-facebook-f"></i></a>
                                <a href="https://twitter.com/GRAD46187534"><i class="fab fa-twitter"></i></a>
                                <a href="https://www.instagram.com/grad_graduates/?hl=en"><i class="fab fa-instagram"></i></a> 				
                            </div>
                        </div>
                    </div>
                </div>
            </footer>

</body>
</html>