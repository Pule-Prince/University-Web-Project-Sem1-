<?php
include_once("event/isloggedin.php");
include_once("event/conn.php");
?>

<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>G.R.A.D | Register</title>

    <link
      href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css"
      rel="stylesheet"
    />
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>

    <link rel="stylesheet" href="css/colors.css" />
    <link rel="stylesheet" href="css/navbar.css" />
    <link rel="stylesheet" href="css/form.css" />

    <link rel="preconnect" href="https://fonts.googleapis.com" />
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
    <link
      href="https://fonts.googleapis.com/css2?family=Poppins:wght@100;200;300;400;600;700&display=swap"
      rel="stylesheet"
    />
    <script
      src="https://kit.fontawesome.com/da7a0ef97e.js"
      crossorigin="anonymous"
    ></script>
  </head>
  <body>

  <!-- validate form -->
  <?php
  $mess="";
  $error=true;
  $em="";
  $pa="";
  $nam="";
  $success="";
  if (isset($_POST["submit"])){
    
    if(!isset($_POST['email'],$_POST['pass'],$_POST['name'])){
      $mess = "Fill the form";
    }
    else{
     $email=trim(strtolower($_POST['email']));
     $pass=trim($_POST['pass']);
     $name=trim($_POST['name']);

     $nam=$name;
     $pa=$pass;
     $em=$email;
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
      $mess = "Invalid email";
     }else if (empty(trim($name))) {
      $mess = "Name is required";
     }
     else if (empty(trim($pass))) {
      $mess = "Password is required";
     }
   
     else if((sizeof($_FILES))==0)   $mess = "Upload a profile picture";
     else if(strlen(trim($pass))<5)  $mess = "Password is too short must be > 5";
     else if(strlen(trim($name))<3)  $mess = "Name is too short must be > 2";
     else{
      $error=false;
     }

     
    }
  }
?>
<!-- end form validation -->

<?php
$uploadOk = 1;

$target_file="";
if (isset($_POST["submit"])){
    

$target_dir = "uploads/";
$target_file = $target_dir .$em. basename($_FILES["profile"]["name"]);

$imageFileType = strtolower(pathinfo($target_file,PATHINFO_EXTENSION));
// Check if image file is a actual image or fake image

if($_FILES["profile"]["size"]==0){
  $mess= "File is required.";
   $uploadOk=0;
}else{  
    $check = getimagesize($_FILES["profile"]["tmp_name"]);
    if($check !== false) {
      //echo "File is an image - " . $check["mime"] . ".";
      $uploadOk = 1;
    } else {
      $mess= "File is not an image.";
      $uploadOk = 0;
    }
  
}

}
?>


<!-- check user if exist in the database -->
 <?php
    //if the message length==0
    // then we don't have form errors
    if($error==false && $uploadOk==1){

      //limit the users by 1
      $sql = "SELECT * FROM users WHERE email='$email'";
      $result = mysqli_query($conn, $sql);

      if (mysqli_num_rows($result) > 0) {
         $mess="account exist , please login";
      } else {
        move_uploaded_file($_FILES['profile']['tmp_name'],$target_file);
        $sql="INSERT INTO `users`( `email`, `pass`, `name`, `profile`) VALUES ('$email','$pass','$nam','$target_file')";
        if (mysqli_query($conn, $sql)) {
          $success ="Account created successfully , now you can login";
        } else {
          echo "Error: " . $sql . "<br>" . mysqli_error($conn);
        }
      }
    }

?>
<!-- end checking u -->

<nav> 
      <div class="logo">
        <i class="fa fa-graduation-cap" aria-hidden="true"></i>G.R.A.D
      </div>
      <div class="navLinks">
        
        <div class="text-white">|</div>
        <a href="login.php"> <i class="fa fa-lock" aria-hidden="true"></i>  Login</a>
      </div>
    </nav>

    <form class="form"  enctype="multipart/form-data" action="register.php" role = "form" method = "post">
    <div class="text-danger text-center">
           <?php echo $mess ?>
      </div>

      <div class="text-success text-center">
           <?php echo  $success ?>
         </div>
      <h3 class="logo">
        <i class="fa fa-graduation-cap" aria-hidden="true"></i>G.R.A.D
      </h3>
      <h2 class="text-center text-white"><b>Register</b></h2>
      <label>Your Profile Image</label>
      <input name="profile" type="file" />
      <label>Name</label>
      <input name="name" type="text"  value="<?php echo $nam ?>" />
      <label >Email</label>
      <input name="email" type="text" value="<?php echo $em  ?>" />
      <label>Password</label>
      <input name="pass" type="password"  value="<?php echo $pa  ?>" />
      <button  type="submit" name="submit"  class="btn btn-block">Register</button>
      <a href="index.php">back</a>
  </form>
  
  </body>
</html>
