<?php
 include_once("event/notloggedIn.php");
 include_once("event/conn.php");
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>G.R.A.D | Dashboard</title>

    <link
      href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css"
      rel="stylesheet"
    />
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>

    <link rel="stylesheet" href="css/colors.css" />
    <link rel="stylesheet" href="css/navbar.css" />
    <link rel="stylesheet" href="css/cvslist.css" />
    <link rel="stylesheet" href="css/footer.css" />

    <link rel="preconnect" href="https://fonts.googleapis.com" />
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
    <link
      href="https://fonts.googleapis.com/css2?family=Poppins:wght@100;200;300;400;600;700&display=swap"
      rel="stylesheet"
    />
    <script
      src="https://kit.fontawesome.com/da7a0ef97e.js"
      crossorigin="anonymous"
    ></script>
  </head>
  <body>
    <nav>
      <div class="logo" >
        <i class="fa fa-graduation-cap" aria-hidden="true"></i>G.R.A.D
      </div>
      <div class="navLinks">
        <a href="#" class="active">Home</a>
        <a href="Resources.php"> <i class="fa-solid fa-layer-group"></i> Resources</a>
        <div class="text-white">|</div>
        <a href="postcv.php"> <i class="fa fa-lock" aria-hidden="true"></i> Post</a>
        <div class="text-white">|</div>
        <a href="profile.php"> <i class="fa fa-user" aria-hidden="true"></i> Profile</a>
        <div class="text-white">|</div>
        <a href="event/logout.php">Logout</a>
      </div>
    </nav>
    <div class="header-image">
          <div class="header-image-text">
            Welcome <i class="text-danger"> <?php echo $_SESSION["name"]; ?> </i> to  G.R.A.D Dashboard
          </div>
    </div>

    <div class="container-fluid">
      <h3 class="py-4 text-center">Manage Your Documents</h3>
      <hr>

      <table class="table table-hover">
    <thead>
      <tr>
        <th>Name</th>
        <th>Skills</th>
        <th>File</th>
        <th>Delete</th>
      </tr>
    </thead>
    <?php
      $id=$_SESSION["id"];
      $data=[];
      $sql = "SELECT * FROM `documents` WHERE  user_id=$id";
      $result = mysqli_query($conn, $sql);

      if (mysqli_num_rows($result) > 0) {
        // output data of each row
        while($row = mysqli_fetch_assoc($result)) {
          $data[]=$row;
        }
      } else {
        echo "0 results";
      }

    ?>
    <tbody>
      <?php
        foreach($data as $row)
        {
      ?>
    
    <tr>
        <td><?php echo $_SESSION["name"]; ?></td>
        <td><?php echo $row['skills']; ?></td>
        <td>
          <a href="<?php echo $row['path']  ?>">Attachment</a>
        </td>
        <td>
          <a href="dashboard.php?id=<?php echo $row['id']  ?>" class="btn btn-danger">Delete</a>
        </td>
    </tr>
  
  <?php
    }
    ?>
    </tbody>
  </table>

  <?php


//delete file
if(isset($_GET["id"])){
  $id=trim($_GET["id"]);
  $sql="DELETE FROM documents WHERE `documents`.`id` = $id";
  if (!mysqli_query($conn, $sql)) {
    echo "Error: " . $sql . "<br>" . mysqli_error($conn);
  }
  header("location: dashboard.php");
}


?>

    </div>
    <footer class="footer">
            <div class="container">
                <div class="footerRows">
                    <div class="column">
                        <div class="logo"><i class="fa fa-graduation-cap" aria-hidden="true"></i>G.R.A.D</div>
                        <span id="summary">       
                            G.R.A.D is a startup website made
                            by second year students at the 
                            University of Johannesburg. We are
                            aware of the problem we have been
                            facing regarding unemployment and
                            job searching in general, and we want
                            fill that void.
                        </span>
                    </div>
                    <div class="column">
                        <h4>Quick Links</h4>
                        <ul>
                            <li><a href="event/logout.php">Logout</a></li>
                        </ul>
                    </div>
                    <div class="column">
                        <h4>Extra Links</h4>
                        <ul>
                            <li><a href="register.php">Sign Up</a></li>
                            <li><a href="#">Login</a></li>
                        </ul>
                    </div>
                    <div class="column">
                        <h4>Follow Us</h4>
                        <div class="links">
                            <a href="#"><i class="fab fa-facebook-f"></i></a>
                            <a href="#"><i class="fab fa-twitter"></i></a>
                            <a href="#"><i class="fab fa-instagram"></i></a> 				
                        </div>
                    </div>
                </div>
            </div>
        </footer>
  </body>
</html>
